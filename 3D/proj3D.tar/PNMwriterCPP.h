#include <sink.h>

class PNMwriterCPP : public Sink
{
	public:
		void Write(char *filename);
};
