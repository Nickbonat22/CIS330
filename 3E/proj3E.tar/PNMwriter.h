#include <sink.h>

class PNMwriter : public Sink
{
	public:
		void Write(char *filename);
};
